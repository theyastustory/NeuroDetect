from django.urls import path
from .views import dashboard, update_brain_age

urlpatterns = [
    path('dashboard/', dashboard),
    path('brain-age/', update_brain_age),
]
